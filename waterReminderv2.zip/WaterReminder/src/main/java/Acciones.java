/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Danie_2rs1q2u
 */
import java.sql.*;

public class Acciones {
    Conexion cone = new Conexion();
    
    public int registrar(Persona per){
        int estatus =0;
            Connection con = Conexion.conectar();
            
            try {
		
                Statement set = null;
            	ResultSet rs = null;
                set = con.createStatement();
                String q1 = "insert into persona values (null,?,?,?,?,?,?,?,?,?,1,1)";
                PreparedStatement ps = con.prepareStatement(q1);
                
                ps.setString(1, per.getNombre());
                ps.setString(2, per.getPassword());
                ps.setInt(3,per.getPeso());
                ps.setString(4, per.getAltura());
                ps.setInt(5, per.getEdad());
                ps.setString(6, per.getMeta());
                ps.setString(7, per.getDespertar());
                ps.setString(8, per.getDormir());
                ps.setInt(9, per.getSexo());
                
                
                estatus = ps.executeUpdate();
                
                System.out.println("Registro Exitoso");
                con.close();
            } catch (SQLException e) {
                System.out.println("error al registrar");
                System.out.println(e.getMessage());
            }
            return estatus;
       
}

}