/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Danie_2rs1q2u
 */
@WebServlet(urlPatterns = {"/Verificar"})
public class Verificar extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //pedir los parametros
        response.setContentType("text/html;charset=UTF-8");
        String action = request.getParameter("action");
        String action2 = "Registrarse";
        if (action.equals(action2)){
            //comprobar que el usuario no exista
            String nombre = request.getParameter("name");
            Persona p1 = new Persona();
            p1.setNombre(nombre);
            Acciones verificar = new Acciones();
            int r = verificar.verificar(p1);
            if (r > 0){
                response.sendRedirect("registrar.html");
                System.out.println("usuario ya exitente");
            }else{
            String nombre2 = request.getParameter("name");
            String altura = request.getParameter("altura");
            int sexo = Integer.parseInt(request.getParameter("sexo"));
            int edad = Integer.parseInt(request.getParameter("edad"));
            String despertar= request.getParameter("despertar");
            String dormir = request.getParameter("dormir");
            int peso = Integer.parseInt(request.getParameter("peso"));
            String password2 = request.getParameter("pass");
            int meta = peso * 40;
            String metafinal= meta+"";
            //encapsular enviar a persona
            Persona p = new Persona();
            p.setMeta(altura);
            p.setNombre(nombre2);
            p.setAltura(altura);
            p.setSexo(sexo);
            p.setEdad(edad);
            p.setDespertar(despertar);
            p.setDormir(dormir);
            p.setPeso(peso);
            p.setPassword(password2);
            p.setMeta(metafinal);

            //registrar a la persona
            Acciones registrar = new Acciones();
            int setatus = registrar.registrar(p);
            if (setatus > 0 ){
                response.sendRedirect("login.html");
            }else{
                response.sendRedirect("index.html");
            }
            }
        }
        action2 = "Iniciar Sesion";
        if (action.equals(action2)){
            String nombre = request.getParameter("name");
            String password = request.getParameter("pass");
            System.out.println("AAAAA");
            Persona p1 = new Persona();
            p1.setNombre(nombre);
            p1.setPassword(password);
            Acciones verificar = new Acciones();
            int r = verificar.verificar(p1);
            if (r > 0){
                response.sendRedirect("registrar.html");
                System.out.println("usuario ya exitente");
            }else{
            
            }
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
