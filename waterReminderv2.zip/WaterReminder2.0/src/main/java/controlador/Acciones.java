package controlador;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Danie_2rs1q2u
 */
import modelo.Persona;
import java.sql.*;

public class Acciones {
    Conexion cone = new Conexion();
    
    public int registrar(Persona per){
        int estatus =0;
            Connection con = Conexion.conectar();
            
            try {
		
                Statement set = null;
            	ResultSet rs = null;
                set = con.createStatement();
                String q1 = "insert into persona values (null,?,?,?,?,?,?,?,?,?,1,1)";
                PreparedStatement ps = con.prepareStatement(q1);
                
                ps.setString(1, per.getNombre());
                ps.setString(2, per.getPassword());
                ps.setInt(3,per.getPeso());
                ps.setString(4, per.getAltura());
                ps.setInt(5, per.getEdad());
                ps.setString(6, per.getMeta());
                ps.setString(7, per.getDespertar());
                ps.setString(8, per.getDormir());
                ps.setInt(9, per.getSexo());
                
                
                estatus = ps.executeUpdate();
                
                System.out.println("Registro Exitoso");
                con.close();
            } catch (SQLException e) {
                System.out.println("error al registrar");
                System.out.println(e.getMessage());
                return estatus;
            }
            return estatus;
    }
    
    public int login(Persona per){
        int estatus =0;
            Connection con = Conexion.conectar();
            try {
                Statement set = null;
            	ResultSet rs = null;
                set = con.createStatement();
                String q1 = "select * from persona where nombre=? and password=?";
                PreparedStatement ps = con.prepareStatement(q1);
                ps.setString(1, per.getNombre());
                ps.setString(2, per.getPassword());
                rs = ps.executeQuery();
                
                if(rs.next()){
                    int a = rs.getInt("idPersona");
                    ResultSet rs2 = null;
                    System.out.println(a);
                    set = con.createStatement();
                    String q2 = "select * from taza where Persona_idPersona="+a;
                    PreparedStatement ps2 = con.prepareStatement(q2);
                    rs2 = ps2.executeQuery();
                    if(rs2.next()){
                    }else{
                        ResultSet rs3 = null;
                        System.out.println(a);
                        set = con.createStatement();
                        String q3 = "insert into taza values (null, 400,"+a+")";
                        PreparedStatement ps3 = con.prepareStatement(q3);
                        ps3.executeUpdate();
                        
                    }
                        
                    estatus = 1;
                }else{
                    estatus = 0;
                }
                con.close();
            } catch (SQLException e) {
                System.out.println("error al registrar");
                System.out.println(e.getMessage());
                return estatus;
            }
            return estatus;
    }
    
    public int verificar(Persona per){
        int estatus = 0;
            Connection con = Conexion.conectar();
            try {
                Statement set = null;
            	ResultSet rs = null;
                set = con.createStatement();
                String q1 = "select * from persona where nombre=?";
                PreparedStatement ps = con.prepareStatement(q1);
                ps.setString(1, per.getNombre());
                rs = ps.executeQuery();
                if(rs.next()){
                    System.out.println(rs.getString("nombre"));
                    estatus = 1;
                }else{
                    estatus = 0;
                }
                con.close();
            } catch (SQLException e) {
                System.out.println("error al registrar");
                System.out.println(e.getMessage());
                return estatus;
            }
            return estatus;
    }
}