package controlador;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Alumno
 */

import java.sql.*;



public class Conexion {
    
    public static Connection conectar(){
        Connection con = null;
        String url, name, pass;
        url = "jdbc:mysql://localhost:3306/waterreminder";
        name = "root";
        pass = "n0m3l0";
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url, name, pass);
            System.out.println("Se realizo la conexion a la base de datos");
            return con;
        }catch(SQLException sq){
            System.out.println("Error al conectar la BD");
            System.out.println(sq.getMessage());
        }catch(Exception ex){
            System.out.println("Error al no encontrar la clase");
            System.out.println(ex.getMessage());
            return null;
        }
        return con;
    }
    
}