/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;

/**
 *
 * @author Danie_2rs1q2u
 */
public class Consultas {
    
    
    
    public String Consultarhomemeta (String a){
        String b = "a";
        Connection con = Conexion.conectar();
            
            try {
                Statement set = null;
            	ResultSet rs = null;
                set = con.createStatement();
                String q1 = "select * from persona where nombre=?";
                PreparedStatement ps = con.prepareStatement(q1);
                ps.setString(1, a);
                rs = ps.executeQuery();
                if (rs.next()){
                b = rs.getString("meta_agua");
                }
                con.close();
            } catch (SQLException e) {
                System.out.println("error al registrar");
                System.out.println(e.getMessage());
            }catch(Exception exception1){
                System.out.println("error al registrar");
                System.out.println(exception1.getMessage());
            }
        
            return b;
        }
    public int ConsultarTaza (String a){
        int b = 0 ;
        Connection con = Conexion.conectar();
            
            try {
                Statement set = null;
            	ResultSet rs = null;
                set = con.createStatement();
                String q1 = "select cantidad from taza D join persona E on D.Persona_idPersona = E.idPersona where nombre = ?";
                PreparedStatement ps = con.prepareStatement(q1);
                ps.setString(1, a);
                rs = ps.executeQuery();
                if (rs.next()){
                b = rs.getInt("cantidad");
                }
                con.close();
            } catch (SQLException e) {
                System.out.println("error al registrar");
                System.out.println(e.getMessage());
            }catch(Exception exception1){
                System.out.println("error al registrar");
                System.out.println(exception1.getMessage());
            }
        
            return b;
        }
    
    public void consumir(String nombre, String cantidad ){
        Connection con = Conexion.conectar();
            try {
                Statement set = null;
            	ResultSet rs = null;
                set = con.createStatement();
                String q1 = "select * from persona where nombre =?";
                PreparedStatement ps = con.prepareStatement(q1);
                ps.setString(1, nombre);
                rs = ps.executeQuery();
                if(rs.next()){
                    Calendar fecha = Calendar.getInstance();
                    int ano = fecha.get(Calendar.YEAR);
                    int mes = fecha.get(Calendar.MONTH) + 1;
                    int dia = fecha.get(Calendar.DAY_OF_MONTH);
                    
                    String mes2;
                    String dia2;
                    
                    if (mes <=9){
                        mes2 = "0"+mes;
                    }else{
                        mes2 = mes+"";
                        }
                    if (dia <=9){
                        dia2 = "0"+dia;
                    }else{
                        dia2 = dia+"";
                        }
                    System.out.println("Fecha Actual: "+ dia2 + "/" + (mes2) + "/" + ano);
                    int b = rs.getInt("idPersona");
                    Statement set2 = null;
                    ResultSet rs2 = null;
                    set = con.createStatement();
                    int cantidad2 = Integer.parseInt(cantidad);
                    String q2 = "insert into consumo_agua values (null, ?,"+ano+""+mes2+""+dia2+","+b+")";
                    PreparedStatement ps2 = con.prepareStatement(q2);
                    ps2.setInt(1, cantidad2);
                    ps2.executeUpdate();
                }
                con.close();
            } catch (SQLException e) {
                System.out.println("error al registrar");
                System.out.println(e.getMessage());
            }catch(Exception exception1){
                System.out.println("error al registrar");
                System.out.println(exception1.getMessage());
            }
        }
    
    }   

    

