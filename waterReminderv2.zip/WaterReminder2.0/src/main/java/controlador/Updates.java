/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import modelo.Persona;

/**
 *
 * @author Alumno
 */
public class Updates {
    
    public int editarPeso (Persona p){
        int estatus = 0;
         Connection con = Conexion.conectar();
            
            try {
                Statement set = null;
            	ResultSet rs = null;
                set = con.createStatement();
                String nombre = p.getNombre();
                String q1 = "select * from persona where nombre ='"+nombre+"'";
                PreparedStatement ps = con.prepareStatement(q1);
                rs = ps.executeQuery();
                if (rs.next()){
                    try{
                        int peso = p.getPeso();
                        int sexo  = rs.getInt("Sexo_idsexo");
                        if (sexo == 1){
                            int meta = peso * 40;
                            set = con.createStatement();
                            int id = rs.getInt("idPersona");
                            String q2 = "update persona set peso="+peso+" set  meta_agua = "+meta+"where Persona_idPersona = "+id;
                            PreparedStatement ps2 = con.prepareStatement(q2);
                            ps2.executeUpdate();
                        }
                        if (sexo == 2){
                             int meta = peso * 35;
                            set = con.createStatement();
                            int id = rs.getInt("idPersona");
                            String q2 = "update persona set peso="+peso+" set  meta_agua = "+meta+"where Persona_idPersona = "+id;
                            PreparedStatement ps2 = con.prepareStatement(q2);
                            ps2.executeUpdate();
                        }
                    
                    }  catch (SQLException e) {
                        System.out.println("error al registrar");
                        System.out.println(e.getMessage());
                          return estatus ;
                    }catch(Exception exception1){
                        System.out.println("error al registrar");
                        System.out.println(exception1.getMessage());
                          return estatus ;
                    }
                
                }
                con.close();
            } catch (SQLException e) {
                System.out.println("error al registrar");
                System.out.println(e.getMessage());
                  return estatus ;
            }catch(Exception exception1){
                System.out.println("error al registrar");
                System.out.println(exception1.getMessage());
                  return estatus ;
            }
        
        return estatus ;
    }
    
    
    public int editarTaza (Persona p){
        int estatus = 0;
         Connection con = Conexion.conectar();
            
            try {
                Statement set = null;
            	ResultSet rs = null;
                set = con.createStatement();
                String nombre = p.getNombre();
                String q1 = "select * from persona where nombre ='"+nombre+"'";
                PreparedStatement ps = con.prepareStatement(q1);
                rs = ps.executeQuery();
                if (rs.next()){
                    try{
                        int cantidad = p.getTaza();
                        set = con.createStatement();
                        int id = rs.getInt("idPersona");
                        String q2 = "update taza set cantidad ="+cantidad+" where Persona_idPersona = "+id+"; '";
                        PreparedStatement ps2 = con.prepareStatement(q2);
                        ps2.executeUpdate();
                    
                    
                    }  catch (SQLException e) {
                        System.out.println("error al registrar");
                        System.out.println(e.getMessage());
                          return estatus ;
                    }catch(Exception exception1){
                        System.out.println("error al registrar");
                        System.out.println(exception1.getMessage());
                          return estatus ;
                    }
                rs.getString("meta_agua");
                }
                con.close();
            } catch (SQLException e) {
                System.out.println("error al registrar");
                System.out.println(e.getMessage());
                  return estatus ;
            }catch(Exception exception1){
                System.out.println("error al registrar");
                System.out.println(exception1.getMessage());
                  return estatus ;
            }
        
        return estatus ;
    }
    
}
