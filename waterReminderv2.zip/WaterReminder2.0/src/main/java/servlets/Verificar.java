package servlets;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import controlador.Acciones;
import modelo.Persona;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Danie_2rs1q2u
 */
@WebServlet(urlPatterns = {"/Verificar"})
public class Verificar extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        //pedir los parametros
        
        String action = request.getParameter("action");
       
        String nombre = request.getParameter("name");
        String altura = request.getParameter("altura");
        String sexo = request.getParameter("sexo");
        String edad = request.getParameter("edad");
        String despertar= request.getParameter("despertar");
        String dormir = request.getParameter("dormir");
        String peso = request.getParameter("peso");
        String password2 = request.getParameter("pass");
        //asegurarse que no sean nulos o q se modifico el html
        
        if (nombre.equals("Drop database") || password2.equals("Drop database")){
                response.sendRedirect("registrar.html");
            }
        if (action == null || nombre == null || altura == null
            || sexo == null || edad == null || despertar == null 
                || dormir == null || peso == null || password2 == null){
            response.sendRedirect("index.html");
            System.out.println("falta un campo en registrar");
            action = "No registrar";
        }
        String action2 = "Registrarse";
        if (action.equals(action2)){
            //comprobar que el usuario no exista
           
            Persona p1 = new Persona();
            p1.setNombre(nombre);
            Acciones verificar = new Acciones();
            int r = verificar.verificar(p1);
            if (r > 0){
                response.sendRedirect("registrar.html");
                System.out.println("usuario ya exitente");
            }else{
                
                }
            
            //Parsear sexo y altura a integers
            int sexo2 = Integer.parseInt(sexo);
            int peso2 = Integer.parseInt(peso);
            int edad2 = Integer.parseInt(edad);
            
            //Calcular la cantidad de agua
            int meta = 1 ;
            int hombre = 1;
            int mujer = 2;
            if(sexo2 == 1){
               meta = peso2 * 40;
            
            }
            if (sexo2 == 2){
                meta = peso2 * 35;
            }
            String metafinal= meta+"";
            
           
            //encapsular enviar a persona
            Persona p = new Persona();
            p.setNombre(nombre);
            p.setAltura(altura);
            p.setSexo(sexo2);
            p.setEdad(edad2);
            p.setDespertar(despertar);
            p.setDormir(dormir);
            p.setPeso(peso2);
            p.setPassword(password2);
            p.setMeta(metafinal);

            //registrar a la persona
            Acciones registrar = new Acciones();
            int setatus = registrar.registrar(p);
            if (setatus > 0 ){
                response.sendRedirect("login.html");
            }else{
                response.sendRedirect("registrar.jsp");
            }
            }
        }
        
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
