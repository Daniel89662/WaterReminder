
setInterval(
	function()
	{
		var f=new Date();
		
		// mostramos la hora actual
		document.getElementById("reloj").innerHTML = "La hora actual es: "+f.getHours()+":"+f.getMinutes()+":"+f.getSeconds();

		// si la hora actual coincide con la hora indicada...
		if( f.getHours()==document.getElementById("hora").value &&
			f.getMinutes()==document.getElementById("minutos").value
		)
		{
			var audio = new Audio('alarm.mp3');

			// al finalizar el sonido escondemos el mensaje de "Alarma sonando"
			audio.onended=function(){
				document.getElementById("sono").innerHTML="";
			};
			document.getElementById("sono").innerHTML="<h1>Alarma sonando</h1>";
			
			// Iniciamos el sonido
			audio.play();
		}
	},1000
);
